#!/usr/bin/env python3
import argparse
import json
import time
from app.config import settings
from app.db import connect, init_db, state_set
from app.helius import get_transactions, HeliusError, QuotaExhausted
from app.parser import parse_swap_signal


def _seed_wallets(con, wallets):
    now = int(time.time())
    for w in wallets:
        con.execute("INSERT OR IGNORE INTO wallets(address,label,source,added_at) VALUES(?,?,?,?)", (w, "", "env", now))


def run_once() -> dict:
    cfg = settings()
    init_db(cfg.sqlite_path)
    started = int(time.time())
    fetched = 0
    with connect(cfg.sqlite_path) as con:
        _seed_wallets(con, cfg.smart_wallets)
        rid = con.execute("INSERT INTO runs(started_at,status) VALUES(?, 'running')", (started,)).lastrowid
        try:
            wallets = [r[0] for r in con.execute("SELECT address FROM wallets ORDER BY address")]
            tracked = set(cfg.tracked_mints)
            if not wallets:
                raise HeliusError("SMART_WALLETS kosong; isi env atau tabel wallets")
            for wallet in wallets:
                txs = get_transactions(wallet, cfg.helius_api_key, limit=cfg.fetch_limit)
                for tx in txs:
                    for s in parse_swap_signal(tx, wallet, tracked):
                        cur = con.execute(
                            "INSERT OR IGNORE INTO signals(signature,wallet,mint,side,amount,usd,ts,slot,raw_json) VALUES(?,?,?,?,?,?,?,?,?)",
                            (s["signature"], s["wallet"], s["mint"], s["side"], s["amount"], s["usd"], s["ts"], s["slot"], json.dumps(tx)[:8000]),
                        )
                        fetched += max(0, cur.rowcount)
            con.execute("UPDATE runs SET finished_at=?, status='ok', fetched=? WHERE id=?", (int(time.time()), fetched, rid))
            state_set(con, "degraded", False)
            state_set(con, "last_error", "")
            return {"ok": True, "fetched": fetched, "run_id": rid}
        except QuotaExhausted as e:
            state_set(con, "degraded", True)
            state_set(con, "next_retry_at", int(time.time()) + min(3600, cfg.collect_interval_s * 2))
            con.execute("UPDATE runs SET finished_at=?, status='error', error=? WHERE id=?", (int(time.time()), str(e)[:500], rid))
            return {"ok": False, "error": str(e), "quota": True, "run_id": rid}
        except Exception as e:
            con.execute("UPDATE runs SET finished_at=?, status='error', error=? WHERE id=?", (int(time.time()), str(e)[:500], rid))
            state_set(con, "degraded", True)
            state_set(con, "last_error", str(e)[:500])
            return {"ok": False, "error": str(e), "run_id": rid}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=None)
    args = ap.parse_args()
    cfg = settings()
    if not args.once and not args.loop:
        ap.error("pilih --once atau --loop")
    while True:
        res = run_once()
        print(json.dumps(res, ensure_ascii=False), flush=True)
        if args.once:
            raise SystemExit(0 if res.get("ok") else 2)
        time.sleep(args.interval or cfg.collect_interval_s)

if __name__ == "__main__":
    main()
