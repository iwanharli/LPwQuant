#!/usr/bin/env python3
import os
import sys
import tempfile
from pathlib import Path
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# Smoke tanpa API key: API harus hidup, status jujur stale/degraded, bukan crash.
with tempfile.TemporaryDirectory() as td:
    os.environ["SQLITE_PATH"] = str(Path(td) / "smoke.db")
    os.environ.pop("HELIUS_API_KEY", None)
    from app.main import app
    c = TestClient(app)
    assert c.get("/healthz").status_code == 200
    st = c.get("/api/status")
    assert st.status_code == 200, st.text
    data = st.json()
    assert data["mode"] in {"stale", "degraded", "fresh"}
    assert data["has_helius_key"] is False
    assert c.get("/api/smart-money").status_code == 200
print("SMOKE OK")
