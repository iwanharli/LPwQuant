import os
from dataclasses import dataclass
from pathlib import Path


def _csv(name: str) -> list[str]:
    raw = os.getenv(name, "")
    return [x.strip() for x in raw.split(",") if x.strip()]


@dataclass(frozen=True)
class Settings:
    helius_api_key: str
    sqlite_path: Path
    smart_wallets: list[str]
    tracked_mints: list[str]
    collect_interval_s: int
    stale_after_s: int
    fetch_limit: int


def settings() -> Settings:
    return Settings(
        helius_api_key=os.getenv("HELIUS_API_KEY", "").strip(),
        sqlite_path=Path(os.getenv("SQLITE_PATH", "./data/imet-smart-money.db")),
        smart_wallets=_csv("SMART_WALLETS"),
        tracked_mints=_csv("TRACKED_MINTS"),
        collect_interval_s=int(os.getenv("COLLECT_INTERVAL_S", "900")),
        stale_after_s=int(os.getenv("STALE_AFTER_S", "3600")),
        fetch_limit=max(1, min(int(os.getenv("FETCH_LIMIT", "100")), 100)),
    )
