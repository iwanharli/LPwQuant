"""iMet Smart Money Tracker standalone package."""
