import time
from .db import state_get


def _rowdict(row):
    return dict(row) if row else None


def compute_status(con, stale_after_s: int) -> dict:
    last_ok = con.execute("SELECT * FROM runs WHERE status='ok' ORDER BY id DESC LIMIT 1").fetchone()
    last_any = con.execute("SELECT * FROM runs ORDER BY id DESC LIMIT 1").fetchone()
    last_signal = con.execute("SELECT MAX(ts) AS ts, COUNT(*) AS n FROM signals").fetchone()
    now = int(time.time())
    age = now - int(last_ok["finished_at"]) if last_ok and last_ok["finished_at"] else None
    signal_age = now - int(last_signal["ts"]) if last_signal and last_signal["ts"] else None
    degraded = bool(state_get(con, "degraded", False)) or bool(last_any and last_any["status"] == "error")
    if age is None or age > stale_after_s:
        mode = "stale"
    elif degraded:
        mode = "degraded"
    else:
        mode = "fresh"
    return {
        "ok": True,
        "mode": mode,
        "last_success_at": int(last_ok["finished_at"]) if last_ok and last_ok["finished_at"] else None,
        "last_run_at": int(last_any["started_at"]) if last_any else None,
        "last_error": (last_any["error"] if last_any and last_any["error"] else None),
        "next_retry_at": state_get(con, "next_retry_at"),
        "signal_count": int(last_signal["n"] or 0) if last_signal else 0,
        "last_signal_at": int(last_signal["ts"]) if last_signal and last_signal["ts"] else None,
        "last_signal_age_s": signal_age,
        "age_s": age,
        "stale_after_s": stale_after_s,
    }
