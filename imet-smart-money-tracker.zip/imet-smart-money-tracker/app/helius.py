import os
import time
import httpx

class HeliusError(RuntimeError):
    pass

class QuotaExhausted(HeliusError):
    pass

BASE = "https://api.helius.xyz/v0"


def get_transactions(address: str, api_key: str, limit: int = 100, retries: int = 4) -> list[dict]:
    if not api_key:
        raise HeliusError("HELIUS_API_KEY kosong")
    url = f"{BASE}/addresses/{address}/transactions"
    params = {"api-key": api_key, "limit": max(1, min(int(limit), 100))}
    last = ""
    with httpx.Client(timeout=30, headers={"User-Agent": "imet-smart-money/1.0"}) as client:
        for i in range(retries):
            r = client.get(url, params=params)
            if r.status_code == 200:
                data = r.json()
                return data if isinstance(data, list) else []
            last = f"HTTP {r.status_code}: {r.text[:200]}"
            if r.status_code == 429:
                wait = float(r.headers.get("Retry-After") or min(60, 2 ** i))
                time.sleep(wait)
                continue
            raise HeliusError(last)
    raise QuotaExhausted(last or "Helius 429")
