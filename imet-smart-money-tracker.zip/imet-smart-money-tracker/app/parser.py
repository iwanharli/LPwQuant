QUOTE_MINTS = {
    "So11111111111111111111111111111111111111112",
    "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
}


def parse_swap_signal(tx: dict, wallet: str, tracked_mints: set[str]) -> list[dict]:
    """Parse transaksi Helius jadi sinyal sederhana. Konservatif: kalau tak yakin, side=unknown."""
    sig = tx.get("signature") or ""
    ts = int(tx.get("timestamp") or 0)
    slot = int(tx.get("slot") or 0)
    transfers = tx.get("tokenTransfers") or []
    signals = []
    for tr in transfers:
        mint = tr.get("mint")
        if tracked_mints and mint not in tracked_mints:
            continue
        frm = tr.get("fromUserAccount")
        to = tr.get("toUserAccount")
        side = "buy" if to == wallet else "sell" if frm == wallet else "unknown"
        if side == "unknown":
            continue
        signals.append({
            "signature": sig, "wallet": wallet, "mint": mint, "side": side,
            "amount": float(tr.get("tokenAmount") or 0), "usd": 0.0, "ts": ts, "slot": slot,
        })
    return signals
