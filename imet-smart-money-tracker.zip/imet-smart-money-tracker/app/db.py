import json
import sqlite3
from pathlib import Path
from typing import Any

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS wallets(
  address TEXT PRIMARY KEY,
  label TEXT,
  source TEXT DEFAULT 'env',
  added_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS signals(
  signature TEXT NOT NULL,
  wallet TEXT NOT NULL,
  mint TEXT NOT NULL,
  side TEXT NOT NULL CHECK(side IN ('buy','sell','unknown')),
  amount REAL DEFAULT 0,
  usd REAL DEFAULT 0,
  ts INTEGER NOT NULL,
  slot INTEGER DEFAULT 0,
  raw_json TEXT DEFAULT '',
  PRIMARY KEY(signature, wallet, mint)
);
CREATE TABLE IF NOT EXISTS runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  started_at INTEGER NOT NULL,
  finished_at INTEGER,
  status TEXT NOT NULL CHECK(status IN ('running','ok','error')),
  error TEXT DEFAULT '',
  fetched INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS state(k TEXT PRIMARY KEY, v TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_signals_mint_ts ON signals(mint, ts DESC);
CREATE INDEX IF NOT EXISTS idx_signals_wallet_ts ON signals(wallet, ts DESC);
"""


def connect(path: Path | str) -> sqlite3.Connection:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    return con


def init_db(path: Path | str) -> None:
    with connect(path) as con:
        con.executescript(SCHEMA)


def state_get(con: sqlite3.Connection, key: str, default: Any = None) -> Any:
    row = con.execute("SELECT v FROM state WHERE k=?", (key,)).fetchone()
    if not row:
        return default
    try:
        return json.loads(row["v"])
    except Exception:
        return row["v"]


def state_set(con: sqlite3.Connection, key: str, value: Any) -> None:
    con.execute("INSERT OR REPLACE INTO state(k,v) VALUES(?,?)", (key, json.dumps(value)))
