import time
from fastapi import FastAPI, BackgroundTasks
from .config import settings
from .db import connect, init_db
from .status import compute_status

app = FastAPI(title="iMet Smart Money Tracker", version="0.1.0")

@app.on_event("startup")
def _startup():
    init_db(settings().sqlite_path)

@app.get("/healthz")
def healthz():
    return {"ok": True, "service": "imet-smart-money", "ts": int(time.time())}

@app.get("/api/status")
def api_status():
    cfg = settings()
    init_db(cfg.sqlite_path)
    with connect(cfg.sqlite_path) as con:
        s = compute_status(con, cfg.stale_after_s)
        s["wallets_configured"] = len(cfg.smart_wallets)
        s["mints_configured"] = len(cfg.tracked_mints)
        s["has_helius_key"] = bool(cfg.helius_api_key)
        return s

@app.get("/api/smart-money")
def api_smart_money(mint: str = "", limit: int = 50):
    cfg = settings(); init_db(cfg.sqlite_path)
    limit = max(1, min(int(limit), 200))
    with connect(cfg.sqlite_path) as con:
        if mint:
            rows = con.execute("SELECT * FROM signals WHERE mint=? ORDER BY ts DESC LIMIT ?", (mint, limit)).fetchall()
        else:
            rows = con.execute("SELECT * FROM signals ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
        return {"ok": True, "items": [dict(r) for r in rows]}

@app.get("/api/smart-money/{mint}")
def api_smart_money_mint(mint: str):
    cfg = settings(); init_db(cfg.sqlite_path)
    with connect(cfg.sqlite_path) as con:
        rows = con.execute(
            "SELECT wallet, side, COUNT(*) n, SUM(amount) amount, SUM(usd) usd, MAX(ts) last_ts FROM signals WHERE mint=? GROUP BY wallet, side ORDER BY last_ts DESC",
            (mint,),
        ).fetchall()
        return {"ok": True, "mint": mint, "wallets": [dict(r) for r in rows]}

@app.post("/api/collect/run")
def api_collect_run():
    from collector import run_once
    return run_once()
