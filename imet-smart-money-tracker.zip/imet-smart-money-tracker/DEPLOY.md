# Panduan Deploy Server

## Opsi A — Docker Compose (disarankan)
```bash
unzip imet-smart-money-tracker.zip
cd imet-smart-money-tracker
cp .env.example .env
nano .env   # isi HELIUS_API_KEY, SMART_WALLETS, TRACKED_MINTS
docker compose up -d --build
docker compose logs -f collector
curl http://127.0.0.1:8000/healthz
curl http://127.0.0.1:8000/api/status
```

## Opsi B — systemd + venv
```bash
sudo useradd --system --home /opt/imet-smart-money-tracker imet || true
sudo mkdir -p /opt/imet-smart-money-tracker /data
sudo chown -R imet:imet /opt/imet-smart-money-tracker /data
sudo rsync -a ./ /opt/imet-smart-money-tracker/
cd /opt/imet-smart-money-tracker
sudo -u imet python3 -m venv .venv
sudo -u imet .venv/bin/pip install -r requirements.txt
sudo cp .env.example /etc/imet-smart-money.env
sudo nano /etc/imet-smart-money.env
sudo cp systemd/*.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now imet-smart-money-api imet-smart-money-collector
systemctl status imet-smart-money-api imet-smart-money-collector
curl http://127.0.0.1:8000/api/status
```

## Troubleshooting
- `mode=stale`: collector belum pernah sukses atau data terlalu tua.
- `mode=degraded`: run terakhir error/Helius 429. Cek `last_error` dan `next_retry_at`.
- `signal_count=0`: belum ada transaksi tracked mint dari SMART_WALLETS, atau konfigurasi wallet/mint kosong.
- Jangan menaruh API key di command line; simpan di `.env`/`/etc/imet-smart-money.env`.
