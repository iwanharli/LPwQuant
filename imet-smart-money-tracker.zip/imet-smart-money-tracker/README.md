# iMet Smart Money Tracker (Standalone)

Repo kecil untuk memisahkan **Smart Money Tracker iMet** dari dashboard utama. Fokusnya: simpan aktivitas wallet pintar ke SQLite, expose API status/freshness, dan jelas saat data stale/degraded karena Helius 429/quota.

## Fitur
- FastAPI + SQLite, read-only API.
- Collector CLI: `python collector.py --once` atau `--loop`.
- Status jujur: `fresh`, `stale`, `degraded`.
- Aman deploy: secret hanya lewat `.env`, tidak ada API key hardcoded.

## Endpoint
- `GET /healthz` — liveness murah.
- `GET /api/status` — freshness, last error, status Helius/quota.
- `GET /api/smart-money?mint=&limit=50` — sinyal terbaru.
- `GET /api/smart-money/{mint}` — agregasi per token.
- `POST /api/collect/run` — trigger koleksi manual.

## Quickstart Lokal
```bash
cp .env.example .env
# isi HELIUS_API_KEY, SMART_WALLETS, TRACKED_MINTS
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python scripts/smoke_test.py
uvicorn app.main:app --host 0.0.0.0 --port 8000
# terminal lain:
python collector.py --once
```

## Format ENV
```bash
HELIUS_API_KEY=...
SQLITE_PATH=/data/imet-smart-money.db
SMART_WALLETS=wallet1,wallet2,wallet3
TRACKED_MINTS=mint1,mint2
COLLECT_INTERVAL_S=900
STALE_AFTER_S=3600
FETCH_LIMIT=100
```

Jika `HELIUS_API_KEY` kosong atau kena 429, API tetap hidup dan `/api/status` akan menunjukkan `stale/degraded`, bukan pura-pura sehat.
